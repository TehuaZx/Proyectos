module com.pokemon.batallaPokemon {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.pokemon.batallaPokemon.controladores to javafx.fxml;
    exports com.pokemon.batallaPokemon;
}