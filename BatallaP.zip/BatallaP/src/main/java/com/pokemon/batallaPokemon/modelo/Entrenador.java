package com.pokemon.batallaPokemon.modelo;

import java.util.ArrayList;
import java.util.List;

public class Entrenador {
    private List<Pokemon> equipoPokemon;

    public Entrenador() {
        this.equipoPokemon = new ArrayList<>();
    }

    public void agregarPokemon(Pokemon pokemon) {
        if (equipoPokemon.size() < 4) {
            equipoPokemon.add(pokemon);
        }
    }

    public List<Pokemon> getEquipoPokemon() {
        return new ArrayList<>(equipoPokemon); //Devuelve copia de lista de pokemones
    }
}
