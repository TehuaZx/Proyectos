package com.pokemon.batallaPokemon.controladores;

import com.pokemon.batallaPokemon.modelo.Items;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class ControladorMochila {
    @FXML
    private ImageView imagenMochila;
    @FXML
    private ListView<Items> listaObjetos;
    @FXML
    private TextArea descripcionObjeto;

    private Scene escenaAnterior;
    private ControladorBatalla controladorBatalla;

    @FXML
    public void initialize() {
        imagenMochila.setImage(new Image(Objects.requireNonNull(getClass().getResource("/imagenes/mochila.png")).toExternalForm()));

        //Filtrar items con cantidad > 0
        List<Items> itemsDisponibles = Arrays.stream(Items.values()).filter(item -> item.getCantidad() > 0).toList();

        listaObjetos.getItems().addAll(itemsDisponibles);

        //Evento para mostrar descripción al seleccionar
        listaObjetos.setOnMouseClicked(e ->{
            Items seleccionado = listaObjetos.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                switch (seleccionado) {
                    case Pocion:
                        descripcionObjeto.setText("Restaura 20 PS al pokemon actual");
                        break;
                    case Refresco:
                        descripcionObjeto.setText("Restaura 50 PS al pokemon actual");
                        break;
                    case Revivir:
                        descripcionObjeto.setText("Revive a un pokemon y restaura la mitad de sus PS");
                        break;
                    default:
                        descripcionObjeto.setText("");
                }

                //Doble clic para usar objeto
                if (e.getClickCount() == 2) {
                    mostrarSeleccionPokemon(seleccionado);
                }
            }
        });
    }

    private void mostrarSeleccionPokemon(Items item) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/SeleccionItem.fxml"));
            Parent root = loader.load();

            //Obtener controlador
            ControladorSeleccionItem controlador = loader.getController();
            controlador.initialize(controladorBatalla.getJugador().getEquipoPokemon(), item);

            //Obtener escena
            Scene escenaActual = descripcionObjeto.getScene();
            Stage stage = (Stage) escenaActual.getWindow();

            controlador.setEscenaAnterior(escenaAnterior);
            controlador.setControladorBatalla(controladorBatalla);

            //Cambiar escena
            Scene seleccionPokemon = new Scene(root, escenaActual.getWidth(), escenaActual.getHeight());
            stage.setScene(seleccionPokemon);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setEscenaAnterior(Scene escenaAnterior) {
        this.escenaAnterior = escenaAnterior;
    }

    public void setControladorBatalla(ControladorBatalla controladorBatalla) {
        this.controladorBatalla = controladorBatalla;
    }

    @FXML
    private void salir() {
        Stage stage = (Stage) descripcionObjeto.getScene().getWindow();
        stage.setScene(escenaAnterior);
    }
}
