package com.pokemon.batallaPokemon.modelo;

public enum Tipos {
    Fuego, Electrico, Planta, Agua, Volador, Normal
}
