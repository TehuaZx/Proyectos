package com.pokemon.batallaPokemon.controladores;

import com.pokemon.batallaPokemon.modelo.Pokemon;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.List;
import java.util.Objects;

public class ControladorPokemon {
    @FXML
    private HBox contenedorPokemon;
    private List<Pokemon> pokemons;
    private Pokemon pokemonSeleccionado;
    private Scene escenaAnterior;
    private ControladorBatalla controladorBatalla;
    @FXML
    private TextArea consola;

    public void initialize(List<Pokemon> pokemons) {
        this.pokemons = pokemons;
        mostrarPokemones();
    }

    public void setEscenaAnterior(Scene escena) {
        this.escenaAnterior = escena;
    }

    public void setControladorBatalla(ControladorBatalla controlador) {
        this.controladorBatalla = controlador;
    }

    private void mostrarPokemones() {
        contenedorPokemon.getChildren().clear();

        for (Pokemon pokemon : pokemons) {
            Button boton = new Button();
            boton.setGraphic(crearTarjetaP(pokemon));
            boton.setOnAction(e -> {
                if (pokemon.getVidaActual() > 0) {
                    pokemonSeleccionado = pokemon;
                    cerrarEscena();
                } else {
                    consola.setText(pokemon.getNombre() + " Está debilitado.\nElige un pokemon para continuar la batalla");
                }
            });
            contenedorPokemon.getChildren().add(boton);
        }
    }

    private VBox crearTarjetaP(Pokemon pokemon) {
        ImageView imagen = new ImageView(new Image(Objects.requireNonNull(getClass().getResource(pokemon.getImagen())).toExternalForm()));
        imagen.setFitWidth(150);
        imagen.setFitHeight(150);

        Label nombre = new Label(pokemon.getNombre());
        nombre.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ProgressBar barraVida = new ProgressBar(pokemon.getVidaActual() / (double) pokemon.getVida());
        barraVida.setPrefWidth(140);
        barraVida.setPrefHeight(20);
        if (pokemon.getVidaActual() / (double) pokemon.getVida() > 0.7) {
            barraVida.setStyle("-fx-accent: #18bf20");
        } else if (pokemon.getVidaActual() / (double) pokemon.getVida() > 0.3) {
            barraVida.setStyle("-fx-accent: orange");
        } else {
            barraVida.setStyle("-fx-accent: red");
        }

        Label vida = new Label(pokemon.getVidaActual() + "/" + pokemon.getVida() + " PS");
        vida.setStyle("-fx-font-size: 16px;");

        Label nivel_Tipo = new Label("Nv. " + pokemon.getNivel() + " | " + pokemon.getTipo());
        nivel_Tipo.setStyle("-fx-font-size: 16px;");

        //Estilo pokemones derrotados
        if (pokemon.getVidaActual() <= 0) {
            imagen.setOpacity(0.5);
            nombre.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: gray;");
            vida.setStyle("-fx-font-size: 16px; -fx-text-fill: gray;");
            nivel_Tipo.setStyle("-fx-font-size: 16px; -fx-text-fill: gray;");
        }


        VBox tarjeta = new VBox(10, imagen, nombre, barraVida, vida, nivel_Tipo);
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setStyle("-fx-border-color: #ccc; -fx-border-radius: 10; -fx-padding: 15; -fx-background-color: #1bbaf8");
        return tarjeta;
    }

    @FXML
    private void cerrarEscena() {
        Stage stage = (Stage) contenedorPokemon.getScene().getWindow();
        stage.setScene(escenaAnterior);

        if (controladorBatalla != null && pokemonSeleccionado != null) {
            controladorBatalla.pokemonSeleccionado(pokemonSeleccionado);
        }
    }
}
