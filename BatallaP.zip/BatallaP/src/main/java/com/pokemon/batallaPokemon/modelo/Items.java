package com.pokemon.batallaPokemon.modelo;

public enum Items {
    Pocion("Poción", 20, 3),
    Refresco("Refresco", 50, 2),
    Revivir("Revivir", -1, 1);

    private final String nombre;
    private final int valorCuracion;
    private  int cantidad;

    Items(String nombre, int valorCuracion, int cantidadInicial) {
        this.nombre = nombre;
        this.valorCuracion = valorCuracion;
        this.cantidad = cantidadInicial;
    }

    //Getters
    public String getNombre() {
        return nombre;
    }
    public int getValorCuracion() {
        return valorCuracion;
    }
    public int getCantidad() {
        return cantidad;
    }

    //Setter
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void reducirCantidad() {
        if (cantidad > 0) {
            cantidad--;
        }
    }

    @Override
    public String toString() {
        return nombre + "                           x" + cantidad;
    }
}
