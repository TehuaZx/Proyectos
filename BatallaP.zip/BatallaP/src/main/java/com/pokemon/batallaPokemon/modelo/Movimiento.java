package com.pokemon.batallaPokemon.modelo;

public enum Movimiento {
    //Movimientos iniciales
    Impactrueno("Impactrueno", Tipos.Electrico, 40), //Pikachu
    Latigo("Látigo", Tipos.Planta, 25), //Bulbasaur
    Ataque_Ala("Ataque Ala", Tipos.Volador, 30), //Pidgey
    Ascuas("Ascuas", Tipos.Fuego, 30), //Charmander
    Hidrobomba("Hidrobomba", Tipos.Agua, 35), //Squirtle
    Mordisco("Mordisco", Tipos.Normal, 30), //Rattata

    //Movimientos adicionales
    //Pikachu
    Chispa("Chispa", Tipos.Electrico, 45),
    Doble_Equipo("Doble Equipo", Tipos.Electrico, 50),
    Rayo("Rayo", Tipos.Electrico, 60),
    //Charmander
    Colmillo_Igneo("Colmillo igneo", Tipos.Fuego, 50),
    Lanzallamas("Lanzallamas", Tipos.Fuego, 60),
    Cara_Susto("Cara susto", Tipos.Fuego, 45),
    //Bulbasaur
    Derribo("Derribo", Tipos.Planta, 50),
    Hoja_Afilada("Hoja Afilada", Tipos.Planta, 60),
    Dulce_Aroma("Dulce aroma", Tipos.Planta, 45),
    //Squirtle
    Burbuja("Burbuja", Tipos.Agua, 50),
    Acua_cola("Acua-cola", Tipos.Agua, 60),
    Cabezazo("Cabezazo", Tipos.Agua, 45),
    //Pidgey
    Volar("Volar", Tipos.Volador, 45),
    Tornado("Tornado", Tipos.Volador, 50),
    Ciclon("Ciclón", Tipos.Volador, 60),
    //Rattata
    Grunido("Gruñido", Tipos.Normal, 45),
    Rapidez("Rapidez", Tipos.Normal, 50),
    Hipercolmillo("Hipercolmillo", Tipos.Normal, 60);

    private final String nombre;
    private final Tipos tipo;
    private final int potencia;

    Movimiento(String nombre, Tipos tipo, int potencia) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.potencia = potencia;
    }

    //Getters
    public String getNombre() { return nombre; }
    public Tipos getTipo() { return tipo; }
    public int getPotencia() { return potencia; }
}