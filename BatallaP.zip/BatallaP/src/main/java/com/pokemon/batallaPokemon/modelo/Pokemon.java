package com.pokemon.batallaPokemon.modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Pokemon {
    private String nombre;
    private final Tipos tipo;
    private String imagen;
    private int nivel = 1;
    private int exp = 0;
    private int expNecesaria = 100;
    private int vida;
    private int vidaActual;
    private int ataque;
    private int defensa;
    private List<Movimiento> movimientos = new ArrayList<>();
    private Map<Integer, Movimiento> movimientosPorNivel = new HashMap<>();
    private int nivelEvolucion = 5;
    private String nombreEvolucion = null;
    private boolean haEvolucionado = false;


    public Pokemon(String nombre, int vida, int ataque, int defensa, Tipos tipo, String imagen) {
        this.nombre = nombre;
        this.vida = vida;
        this.vidaActual = vida;
        this.ataque = ataque;
        this.defensa = defensa;
        this.tipo = tipo;
        this.imagen = imagen;
    }

    // Getters
    public String getNombre() { return nombre; }
    public int getNivel() { return nivel; }
    public int getExp() { return exp; }
    public int getVida() { return vida; }
    public int getVidaActual() { return vidaActual; }
    public int getAtaque() { return ataque; }
    public int getDefensa() { return defensa; }
    public Tipos getTipo() { return tipo; }
    public String getImagen() { return imagen; }
    public List<Movimiento> getMovimientos() {
        return movimientos;
    }
    public String getNombreEvolucion() { return nombreEvolucion; }

    //Setters
    public void restarVidaActual(int cantidad) {
        this.vidaActual -= cantidad;
    }
    public void sanar(int cantidad) {
        this.vidaActual += cantidad;

        if (this.vidaActual > this.vida) {
            this.vidaActual = this.vida;
        }
    }
    public void vidaCero() {
        this.vidaActual = 0;
    }
    public void setEvolucion(int nivelEvolucion, String nombreEvolucion) {
        this.nivelEvolucion = nivelEvolucion;
        this.nombreEvolucion = nombreEvolucion;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }


    public void agregarMovimiento(Movimiento movimiento) {
        if (movimientos.size() < 4) {
            movimientos.add(movimiento);
        }
    }

    public void agregarMovimientoNivel(int nivel, Movimiento movimiento) {
        movimientosPorNivel.put(nivel, movimiento);
    }

    public boolean ganarExp(int cantidad) {
        this.exp += cantidad;
        boolean subioNivel = false;

        if (this.exp >= expNecesaria) {
            subirNivel();
            this.exp -= expNecesaria;
            //Aumentar exp necesaria con cada nivel
            this.expNecesaria = 100 + (nivel * 20);
            subioNivel = true;
        }

        return subioNivel;
    }

    private void subirNivel() {
        nivel++;
        vida += 10;
        ataque += 5;
        defensa += 3;

        //Verificar si aprende un nuevo movimiento
        if (movimientosPorNivel.containsKey(nivel)) {
            Movimiento nuevomovimiento = movimientosPorNivel.get(nivel);

            //Añadir movimiento solo si hay menos de 4
            if (movimientos.size() < 4) {
                movimientos.add(nuevomovimiento);
            }
        }

        //Verificar si debe evolucionar
        if (nivel == nivelEvolucion && !haEvolucionado && nombreEvolucion != null) {
            evolucionar();
        }
    }

    private void evolucionar() {
        vida = (int)(vida * 1.2);
        vidaActual = vida;
        ataque = (int)(ataque * 1.2);
        defensa = (int)(defensa * 1.2);
    }

    //Verificar si puede evolucionar
    public boolean puedeEvolucionar() {
        return nivel == nivelEvolucion && !haEvolucionado && nombreEvolucion != null;
    }

}