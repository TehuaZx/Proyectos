package com.pokemon.batallaPokemon.modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PokemonBuilder {
    private String nombre;
    private int vida;
    private int ataque;
    private int defensa;
    private Tipos tipo;
    private String imagen;
    private List<Movimiento> movimientos = new ArrayList<>();
    private Map<Integer, Movimiento> movimientosNivel = new HashMap<>();
    private int nivelEvolucion = -1;
    private String nombreEvolucion = null;

    //Setters
    public PokemonBuilder setNombre(String nombre) {
        this.nombre = nombre;
        this.imagen = "/imagenes/" + nombre + ".png";
        return this;
    }
    public PokemonBuilder setVida(int vida) {
        this.vida = vida;
        return this;
    }
    public PokemonBuilder setAtaque(int ataque) {
        this.ataque = ataque;
        return this;
    }
    public PokemonBuilder setDefensa(int defensa) {
        this.defensa = defensa;
        return this;
    }
    public PokemonBuilder setTipo(Tipos tipo) {
        this.tipo = tipo;
        return this;
    }
    public PokemonBuilder setEvolucion(int nivelEvolucion, String nombreEvolucion) {
        this.nivelEvolucion = nivelEvolucion;
        this.nombreEvolucion = nombreEvolucion;
        return this;
    }

    public PokemonBuilder agregarMovimiento(Movimiento movimiento) {
        if (movimientos.size() < 4) {
            this.movimientos.add(movimiento);
        }
        return this;
    }

    public PokemonBuilder agregarMovimientoNivel(int nivel, Movimiento movimiento) {
        this.movimientosNivel.put(nivel, movimiento);
        return this;
    }

    public Pokemon build() {
        Pokemon pokemon = new Pokemon(nombre, vida, ataque, defensa, tipo, imagen);

        //Movimientos iniciales
        for (Movimiento mov : movimientos) {
            pokemon.agregarMovimiento(mov);
        }

        //Movimientos por nivel
        for (Map.Entry<Integer, Movimiento> entry : movimientosNivel.entrySet()) {
            pokemon.agregarMovimientoNivel(entry.getKey(), entry.getValue());
        }

        //Evolucion
        if (nivelEvolucion > 0 && nombreEvolucion != null) {
            pokemon.setEvolucion(nivelEvolucion, nombreEvolucion);
        }

        return pokemon;
    }
}
