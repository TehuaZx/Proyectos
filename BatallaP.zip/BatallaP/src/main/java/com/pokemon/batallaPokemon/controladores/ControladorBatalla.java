package com.pokemon.batallaPokemon.controladores;

import com.pokemon.batallaPokemon.modelo.*;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class ControladorBatalla {
    @FXML
    private StackPane areaBatalla;

    @FXML
    private ImageView fondo, imagenJugador, imagenEnemigo;

    @FXML
    private Label nombreJugador, nombreEnemigo, nivelJugador, nivelEnemigo, vidaJugador, vidaEnemigo;

    @FXML
    private ProgressBar barraVidaJugador, barraVidaEnemigo;

    @FXML
    private TextArea consolaBatalla;

    @FXML
    private HBox contenedorAbajo, contenedorBotones;

    private Pokemon pokemonJugador;
    private Pokemon pokemonEnemigo;
    private final Queue<String> colaMensajes = new LinkedList<>();
    private boolean mostrandoMensaje = false;
    private Entrenador jugador, enemigo;

    @FXML
    private HBox contenedorMovimientos;

    @FXML
    private Button mov1, mov2, mov3, mov4;

    @FXML
    public void initialize() {
            //Configuración y ajuste de Interfáz
        //Ajusta el fondo al tamaño de la ventana
        fondo.fitWidthProperty().bind(areaBatalla.widthProperty());
        fondo.fitHeightProperty().bind(areaBatalla.heightProperty());

        //Ajusta el tamaño de las imágenes con base al tamaño de la ventana
        imagenJugador.fitWidthProperty().bind(areaBatalla.widthProperty().multiply(0.3));
        imagenJugador.fitHeightProperty().bind(areaBatalla.heightProperty().multiply(0.3));

        imagenEnemigo.fitWidthProperty().bind(areaBatalla.widthProperty().multiply(0.3));
        imagenEnemigo.fitHeightProperty().bind(areaBatalla.heightProperty().multiply(0.3));

        //Ajusta el tamaño de las barras de vida con base al tamaño de la ventana
        barraVidaJugador.prefWidthProperty().bind(areaBatalla.widthProperty().multiply(0.15));
        barraVidaEnemigo.prefWidthProperty().bind(areaBatalla.widthProperty().multiply(0.15));

        //Coloca al pokemonJugador abajo a la izquierda
        StackPane.setAlignment(imagenJugador, Pos.BOTTOM_LEFT);
        imagenJugador.setTranslateX(350);
        imagenJugador.setTranslateY(-20);

        //Coloca al pokemonEnemigo arriba a la derecha
        StackPane.setAlignment(imagenEnemigo, Pos.BOTTOM_LEFT);
        imagenEnemigo.setTranslateX(1330);
        imagenEnemigo.setTranslateY(-320);

        //Ajusta el ancho de consola y botones
        contenedorAbajo.widthProperty().addListener((observable, oldValue, newValue) -> {
            double anchoTotal = newValue.doubleValue();
            consolaBatalla.setPrefWidth(anchoTotal / 2 - 10);
            contenedorBotones.setPrefWidth(anchoTotal / 2 - 10);
        });

        jugador = new Entrenador();

        //Crear pokemones y añadirlos al jugador
        jugador.agregarPokemon(new PokemonBuilder()
                .setNombre("Pikachu")
                .setVida(50)
                .setAtaque(20)
                .setDefensa(10)
                .setTipo(Tipos.Electrico)
                .agregarMovimiento(Movimiento.Impactrueno)
                .agregarMovimientoNivel(2, Movimiento.Chispa)
                .agregarMovimientoNivel(3, Movimiento.Doble_Equipo)
                .agregarMovimientoNivel(4, Movimiento.Rayo)
                .setEvolucion(5,"Raichu")
                .build());

        jugador.agregarPokemon(new PokemonBuilder()
                .setNombre("Bulbasaur")
                .setVida(40)
                .setAtaque(18)
                .setDefensa(15)
                .setTipo(Tipos.Planta)
                .agregarMovimiento(Movimiento.Latigo)
                .agregarMovimientoNivel(2, Movimiento.Derribo)
                .agregarMovimientoNivel(3, Movimiento.Hoja_Afilada)
                .agregarMovimientoNivel(4, Movimiento.Dulce_Aroma)
                .setEvolucion(5,"Ivysaur")
                .build());

        jugador.agregarPokemon(new PokemonBuilder()
                .setNombre("Pidgey")
                .setVida(45)
                .setAtaque(17)
                .setDefensa(10)
                .setTipo(Tipos.Volador)
                .agregarMovimiento(Movimiento.Ataque_Ala)
                .agregarMovimientoNivel(2, Movimiento.Volar)
                .agregarMovimientoNivel(3, Movimiento.Tornado)
                .agregarMovimientoNivel(4, Movimiento.Ciclon)
                .setEvolucion(5,"Pidgeotto")
                .build());

        //El primer pokemon a elegir será el primero que se añadió
        pokemonJugador = jugador.getEquipoPokemon().get(0);

        enemigo = new Entrenador();

        Random random = new Random();

        //Crear pokemones y añadirlos al enemigo
        Pokemon charmander = new PokemonBuilder()
                .setNombre("Charmander")
                .setVida(50)
                .setAtaque(20)
                .setDefensa(10)
                .setTipo(Tipos.Fuego)
                .agregarMovimiento(Movimiento.Ascuas)
                .agregarMovimientoNivel(2, Movimiento.Colmillo_Igneo)
                .agregarMovimientoNivel(3, Movimiento.Lanzallamas)
                .agregarMovimientoNivel(4, Movimiento.Cara_Susto)
                .setEvolucion(5,"Charmeleon")
                .build();

        //Nivel aleatorio entre 1 y 5
        int nivelCharmander = random.nextInt(5) + 1;
        for (int i = 1; i < nivelCharmander; i++) {
            charmander.ganarExp(130);
        }
        charmander.sanar(500);

        enemigo.agregarPokemon(charmander);

        Pokemon squirtle = new PokemonBuilder()
                .setNombre("Squirtle")
                .setVida(45)
                .setAtaque(14)
                .setDefensa(18)
                .setTipo(Tipos.Agua)
                .agregarMovimiento(Movimiento.Hidrobomba)
                .agregarMovimientoNivel(2, Movimiento.Burbuja)
                .agregarMovimientoNivel(3, Movimiento.Acua_cola)
                .agregarMovimientoNivel(4, Movimiento.Cabezazo)
                .setEvolucion(5,"Wartortle")
                .build();

        //Nivel aleatorio entre 1 y 5
        int nivelSquirtle = random.nextInt(5) + 1;
        for (int i = 1; i < nivelSquirtle; i++) {
            squirtle.ganarExp(130);
        }
        squirtle.sanar(500);

        enemigo.agregarPokemon(squirtle);

        Pokemon rattata = new PokemonBuilder()
                .setNombre("Rattata")
                .setVida(40)
                .setAtaque(16)
                .setDefensa(10)
                .setTipo(Tipos.Normal)
                .agregarMovimiento(Movimiento.Mordisco)
                .agregarMovimientoNivel(2, Movimiento.Grunido)
                .agregarMovimientoNivel(3, Movimiento.Rapidez)
                .agregarMovimientoNivel(4, Movimiento.Hipercolmillo)
                .setEvolucion(8,"Raticate")
                .build();

        //Nivel aleatorio entre 1 y 5
        int nivelRattata = random.nextInt(5) + 1;
        for (int i = 1; i < nivelRattata; i++) {
            rattata.ganarExp(130);
        }
        rattata.sanar(500);

        enemigo.agregarPokemon(rattata);

        //El primer pokemon a elegir será el primero que se añadió
        pokemonEnemigo = enemigo.getEquipoPokemon().get(0);

        //Configurar pokemones en UI
        configurarPokemonUI(pokemonJugador, nombreJugador, nivelJugador, vidaJugador, pokemonJugador.getVidaActual(), barraVidaJugador, imagenJugador);
        configurarPokemonUI(pokemonEnemigo, nombreEnemigo, nivelEnemigo, vidaEnemigo, pokemonEnemigo.getVidaActual(), barraVidaEnemigo, imagenEnemigo);

        //Configurar botones de movimientos
        mov1.setOnAction(e -> usarMovimiento(0));
        mov2.setOnAction(e -> usarMovimiento(1));
        mov3.setOnAction(e -> usarMovimiento(2));
        mov4.setOnAction(e -> usarMovimiento(3));

        //Mostrar mensaje inicial
        mostrarMensajeDelay("¡Adelante, " + pokemonJugador.getNombre() + "!");
        mostrarMensajeDelay("¿Qué debería hacer " + pokemonJugador.getNombre() + "?");
    }

    private void mostrarMensajeDelay(String mensaje) {
        Platform.runLater(() -> {
            colaMensajes.add(mensaje);
            if (!mostrandoMensaje) {
                mostrarSiguienteMensaje();
            }
        });
    }

    private void mostrarSiguienteMensaje() {
        if (!colaMensajes.isEmpty()) {
            mostrandoMensaje = true;
            setBotonesActivos(false);
            consolaBatalla.setText(colaMensajes.poll());

            PauseTransition delay = new PauseTransition(Duration.seconds(1));
            delay.setOnFinished(e -> mostrarSiguienteMensaje());
            delay.play();
        } else {
            mostrandoMensaje = false;
            setBotonesActivos(true);
        }
    }

    private void setBotonesActivos(boolean activo) {
        contenedorMovimientos.setDisable(!activo);
        contenedorBotones.setDisable(!activo);
    }

    private void configurarPokemonUI(Pokemon pokemon, Label nombre, Label nivel, Label infoVida, double vidaActual, ProgressBar barraVida, ImageView imagen) {
        nombre.setText(pokemon.getNombre());
        if (pokemon == pokemonJugador) {
            nivel.setText("Nv " + pokemon.getNivel() + "   Exp " + pokemon.getExp());
        } else {

            nivel.setText("Nv " + pokemon.getNivel());
        }
        actualizarVidaUI(barraVida, infoVida, vidaActual, pokemon.getVida());
        imagen.setImage(new Image(Objects.requireNonNull(getClass().getResource(pokemon.getImagen())).toExternalForm()));
    }

    private void mostrarMovimientos() {
        List<Movimiento> movimientos = pokemonJugador.getMovimientos();

        //Mostrar botones
        mov1.setText(movimientos.get(0).getNombre());
        if (movimientos.size() > 1) {
            mov2.setText(movimientos.get(1).getNombre());
            mov2.setVisible(true);
        } else {
            mov2.setVisible(false);
        }
        if (movimientos.size() > 2) {
            mov3.setText(movimientos.get(2).getNombre());
            mov3.setVisible(true);
        } else {
            mov3.setVisible(false);
        }
        if (movimientos.size() > 3) {
            mov4.setText(movimientos.get(3).getNombre());
            mov4.setVisible(true);
        } else {
            mov4.setVisible(false);
        }

        //Ocultar botones principales
        contenedorBotones.setVisible(false);
        contenedorMovimientos.setVisible(true);
    }

    @FXML
    private void Atacar() {
        mostrarMovimientos();
    }

    private void usarMovimiento(int indiceMovimiento) {
        Movimiento movimientoJugador = pokemonJugador.getMovimientos().get(indiceMovimiento);

        mostrarMensajeDelay(pokemonJugador.getNombre() + " usó " + movimientoJugador.getNombre() + "!");

        //Calcular ataque
        int ataque = calcularAtaque(pokemonJugador, pokemonEnemigo, movimientoJugador);

        animacionAtaque(pokemonJugador, pokemonEnemigo);

        //Aplicar daño con retraso para sincronizar animación
        PauseTransition pausaAtaque = new PauseTransition(Duration.millis(1000));
        pausaAtaque.setOnFinished(e -> {
            pokemonEnemigo.restarVidaActual(ataque);

            //Actualizar Interfaz
            actualizarVidaUI(barraVidaEnemigo, vidaEnemigo, pokemonEnemigo.getVidaActual(), pokemonEnemigo.getVida());
            mostrarMensajeDelay(pokemonEnemigo.getNombre()+ " perdió " + ataque + " PS!");
            int expGanada = 50 + pokemonEnemigo.getNivel() * 5;
            boolean subioNvl = pokemonJugador.ganarExp(expGanada);

            int delay = 1000;

            if (subioNvl) {
                mostrarMensajeDelay("¡" + pokemonJugador.getNombre() + " subió de nivel!");
                delay += 1000;

                //Verificar si evoluciona
                if (pokemonJugador.puedeEvolucionar()) {
                    evolucion();
                    delay += 3000;
                }

                //Aprender movimientos
                if (pokemonJugador.getMovimientos().size() < 4) {
                    Movimiento nuevoMovimiento = pokemonJugador.getMovimientos().get(pokemonJugador.getMovimientos().size() - 1);
                    mostrarMensajeDelay("¡" + pokemonJugador.getNombre() + " aprendió " + nuevoMovimiento.getNombre() + "!");
                    delay += 1000;
                }
            }

            //Actualizar UI
            nivelJugador.setText("Nv " + pokemonJugador.getNivel() + " Exp " + pokemonJugador.getExp());
            actualizarVidaUI(barraVidaJugador, vidaJugador, pokemonJugador.getVidaActual(), pokemonJugador.getVida());

            //Verificar si se derrotó al enemigo
            if (pokemonEnemigo.getVidaActual() <= 0) {
                pokemonEnemigo.vidaCero();
                actualizarVidaUI(barraVidaEnemigo, vidaEnemigo, pokemonEnemigo.getVidaActual(), pokemonEnemigo.getVida());
                mostrarMensajeDelay("¡Has derrotado a " + pokemonEnemigo.getNombre() + "!\n");
                delay += 1000;

                if (enemigo.getEquipoPokemon().stream().anyMatch(p -> p.getVidaActual() > 0)){
                    PauseTransition pausa = new PauseTransition(Duration.millis(delay));
                    pausa.setOnFinished(ev -> {
                        //Filtar solo pokemones con vida
                        List<Pokemon> pokemonesVivos = enemigo.getEquipoPokemon().stream().filter(p -> p.getVidaActual() > 0).collect(Collectors.toList());

                        //Seleccionar uno aleatoriamente
                        Random random = new Random();
                        this.pokemonEnemigo = pokemonesVivos.get(random.nextInt(pokemonesVivos.size()));

                        //Actualizar UI
                        nombreEnemigo.setText(pokemonEnemigo.getNombre());
                        nivelEnemigo.setText("Nv " + pokemonEnemigo.getNivel());
                        actualizarVidaUI(barraVidaEnemigo, vidaEnemigo, pokemonEnemigo.getVidaActual(), pokemonEnemigo.getVida());
                        imagenEnemigo.setImage(new Image(Objects.requireNonNull(getClass().getResource(pokemonEnemigo.getImagen())).toExternalForm()));

                        mostrarMensajeDelay("¡El entrenador enemigo a escogido a " + pokemonEnemigo.getNombre() + "!");
                    });
                    pausa.play();
                } else {
                    mostrarMensajeDelay("Has ganado la batalla Pokemon");
                    PauseTransition pausa = new PauseTransition(Duration.millis(3040));
                    pausa.setOnFinished(ev -> {
                        setBotonesActivos(false);
                    });
                    pausa.play();
                }

                //Mostrar botones principales
                contenedorMovimientos.setVisible(false);
                contenedorBotones.setVisible(true);
                return;
            }

            //Pausa para animacionRecibirAtaque
            PauseTransition pausaAtaque2 = new PauseTransition(Duration.millis(delay));
            pausaAtaque2.setOnFinished(ev ->{
                //Turno enemigo
                ataqueEnemigo();

                //Mostrar botones principales
                contenedorMovimientos.setVisible(false);
                contenedorBotones.setVisible(true);
            });
            pausaAtaque2.play();
        });
        pausaAtaque.play();
    }

    private void evolucion() {
        mostrarMensajeDelay("¿Qué? ¡" + pokemonJugador.getNombre() + " está evolucionando!");

        //Pausa para efecto
        PauseTransition pausaEvolucion = new PauseTransition(Duration.seconds(2));
        pausaEvolucion.setOnFinished(ev -> {
            String nombreAnterior = pokemonJugador.getNombre();
            String nombreEvolucion = pokemonJugador.getNombreEvolucion();

            //Efecto
            FadeTransition fade = new FadeTransition(Duration.millis(300), imagenJugador);
            fade.setFromValue(1.0);
            fade.setToValue(0.3);
            fade.setCycleCount(6);
            fade.setAutoReverse(true);

            fade.setOnFinished(event -> {
                //Cambiar nombre e imagen
                pokemonJugador.setNombre(nombreEvolucion);
                pokemonJugador.setImagen("/imagenes/" + nombreEvolucion + ".png");

                //Cambiar imagen de pokemon
                try {
                    imagenJugador.setImage(new Image(Objects.requireNonNull(getClass().getResource(pokemonJugador.getImagen())).toExternalForm()));

                    //Actualizar nombre en la UI
                    nombreJugador.setText(pokemonJugador.getNombre());

                    //Actualizar vida en UI
                    actualizarVidaUI(barraVidaJugador, vidaJugador, pokemonJugador.getVidaActual(), pokemonJugador.getVida());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                mostrarMensajeDelay("¡Felicidades! Tu " + nombreAnterior + " ha evolucionado a " + nombreEvolucion + "!");
            });
            fade.play();
        });
        pausaEvolucion.play();
    }

    private void ataqueEnemigo() {
        //Elegir movimiento aleatorio
        List<Movimiento> movimientosEnemigo = pokemonEnemigo.getMovimientos();
        Movimiento movimientoEnemigo = movimientosEnemigo.get((int)(Math.random() * movimientosEnemigo.size()));

        mostrarMensajeDelay(pokemonEnemigo.getNombre() + " usó " + movimientoEnemigo.getNombre() + "!");

        int ataque = calcularAtaque(pokemonEnemigo, pokemonJugador, movimientoEnemigo);

        animacionAtaque(pokemonEnemigo, pokemonJugador);

        //Aplicar daño con retraso para sincronizar animación
        PauseTransition pausaAtaque = new PauseTransition(Duration.millis(1000));
        pausaAtaque.setOnFinished(e -> {
            pokemonJugador.restarVidaActual(ataque);

            //Actualizar UI
            actualizarVidaUI(barraVidaJugador, vidaJugador, pokemonJugador.getVidaActual(), pokemonJugador.getVida());
            mostrarMensajeDelay(pokemonJugador.getNombre() + " perdió " + ataque + " PS!");

            //Verificar si el jugador fue derrotado
            if (pokemonJugador.getVidaActual() <= 0) {
                pokemonJugador.vidaCero();
                actualizarVidaUI(barraVidaJugador, vidaJugador, pokemonJugador.getVidaActual(), pokemonJugador.getVida());
                mostrarMensajeDelay("¡" + pokemonJugador.getNombre() + " ha sido derrotado!\n");
                if (jugador.getEquipoPokemon().stream().anyMatch(p -> p.getVidaActual() > 0)) {
                    PauseTransition pausa = new PauseTransition(Duration.millis(2000));
                    pausa.setOnFinished(ev -> {
                        pokemon();
                    });
                    pausa.play();
                } else {
                    mostrarMensajeDelay("Has perdido la batalla Pokemon");
                    PauseTransition pausa = new PauseTransition(Duration.millis(3040));
                    pausa.setOnFinished(ev -> {
                        setBotonesActivos(false);
                    });
                    pausa.play();
                }
                return;
            }
            mostrarMensajeDelay("¿Qué debería hacer " + pokemonJugador.getNombre() + "?");
        });
        pausaAtaque.play();
    }

    private int calcularAtaque(Pokemon atacante, Pokemon defensor, Movimiento movimiento) {
        double efectividad = calcularEfectividad(movimiento.getTipo(), defensor.getTipo());

        int nivel = atacante.getNivel();
        int ataque = atacante.getAtaque();
        int defensa = atacante.getDefensa();
        int potencia = movimiento.getPotencia();

        double ataqueBase = (((2.0 * nivel / 5 + 2) * ataque * potencia) / defensa) / 50 + 2;
        int ataqueFinal = (int) (ataqueBase * efectividad);

        //Convierte el resultado a entero
        return Math.max(1, ataqueFinal);
    }

    private double calcularEfectividad(Tipos tipoAtaque, Tipos tipoDefensa) {
        if (tipoAtaque == Tipos.Fuego) {
            if (tipoDefensa == Tipos.Planta) return 2;
            if (tipoDefensa == Tipos.Fuego || tipoDefensa == Tipos.Agua) return 0.5;
        } else if (tipoAtaque == Tipos.Electrico) {
            if (tipoDefensa == Tipos.Agua || tipoDefensa == Tipos.Volador) return 2;
            if (tipoDefensa == Tipos.Electrico) return 0.5;
        } else if (tipoAtaque == Tipos.Planta) {
            if (tipoDefensa == Tipos.Fuego || tipoDefensa == Tipos.Planta || tipoDefensa == Tipos.Volador) return 0.5;
            if (tipoDefensa == Tipos.Agua) return 2;
        } else if (tipoAtaque == Tipos.Agua) {
            if (tipoDefensa == Tipos.Fuego) return 2;
            if (tipoDefensa == Tipos.Agua || tipoDefensa == Tipos.Planta) return 0.5;
        } else if (tipoAtaque == Tipos.Volador) {
            if (tipoDefensa == Tipos.Planta) return 2;
            if (tipoDefensa == Tipos.Electrico) return 0.5;
        }
        return 1;
    }

    private void animacionAtaque(Pokemon atacante, Pokemon defensor) {
        ImageView imagenAtacante = imagenJugador;
        ImageView imagenDefensor = imagenEnemigo;

        if (defensor == pokemonJugador) {
            imagenAtacante = imagenEnemigo;
            imagenDefensor = imagenJugador;
        }

        //Guardar posición original
        double posXOriginal = imagenAtacante.getTranslateX();
        double posYOriginal = imagenAtacante.getTranslateY();

        //Posición destino
        double posXDestino;
        double posYDestino;

        if (atacante == pokemonJugador) {
            posXDestino = imagenDefensor.getTranslateX() - 150;
            posYDestino = imagenDefensor.getTranslateY() + 100;
        } else {
            posXDestino = imagenDefensor.getTranslateX() + 150;
            posYDestino = imagenDefensor.getTranslateY() - 100;
        }

        //Animación de ida
        TranslateTransition ida = new TranslateTransition(Duration.millis(450), imagenAtacante);
        ida.setToX(posXDestino);
        ida.setToY(posYDestino);

        //Pausa
        PauseTransition pausa = new PauseTransition(Duration.millis(100));

        //Animación de regreso
        TranslateTransition regreso = new TranslateTransition(Duration.millis(450), imagenAtacante);
        regreso.setToX(posXOriginal);
        regreso.setToY(posYOriginal);

        //Secuencia
        SequentialTransition secuencia = new SequentialTransition(ida, pausa, regreso);

        secuencia.setOnFinished(e -> {
            animacionRecibirAtaque(defensor);
        });

        secuencia.play();
    }

    private void animacionRecibirAtaque(Pokemon defensor) {
        ImageView imagen = imagenEnemigo;

        if (defensor == pokemonJugador) {
            imagen = imagenJugador;
        }

        TranslateTransition vibrar = new TranslateTransition(Duration.millis(100), imagen);
        vibrar.setByX(20);
        vibrar.setCycleCount(4);
        vibrar.setAutoReverse(true);
        vibrar.play();
    }

    private void actualizarVidaUI(ProgressBar barra, Label labelVida, double vidaActual, double vidaMax) {
        double porcentaje = vidaActual / vidaMax;
        actualizarColorVida(barra, porcentaje);
        barra.setProgress(porcentaje);
        labelVida.setText((int)vidaActual + "/" + vidaMax);
    }

    private void actualizarColorVida(ProgressBar vida, double porcentaje) {
        if (porcentaje > 0.7) {
            vida.setStyle("-fx-accent: #18bf20; -fx-min-width: 500px; -fx-pref-height: 35px;");
        } else if (porcentaje > 0.3) {
            vida.setStyle("-fx-accent: orange; -fx-min-width: 500px; -fx-pref-height: 35px;");
        } else {
            vida.setStyle("-fx-accent: red; -fx-min-width: 500px; -fx-pref-height: 35px;");
        }
    }

    @FXML
    private void mochila() {
        try{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Mochila.fxml"));
            Parent root = loader.load();

            //Obtener el controlador
            ControladorMochila controlador = loader.getController();
            controlador.setEscenaAnterior(areaBatalla.getScene());
            controlador.setControladorBatalla(this);

            //Cambiar escena
            Stage stage = (Stage) areaBatalla.getScene().getWindow();
            stage.setScene(new Scene(root, stage.getWidth(), stage.getHeight()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Entrenador getJugador() {
        return jugador;
    }

    public void usarObjeto(Items objeto, Pokemon pokemon) {
        boolean objetoUsado = false;

        switch (objeto) {
            case Pocion:
            case Refresco:
                //Verificar que no exceda vida máxima
                int vidaActual = pokemon.getVidaActual();
                int vidaMax = pokemon.getVida();
                int curacion = objeto.getValorCuracion();

                //Limitar curación para no exceder vida máxima
                int curacionReal = Math.min(curacion, vidaMax - vidaActual);

                //Aplicar curación
                if (objeto == Items.Pocion) {
                    pokemon.sanar(20);
                } else {
                    pokemon.sanar(50);
                }
                mostrarMensajeDelay("¡Usaste " + objeto.getNombre() + " en " + pokemon.getNombre() + "!");
                mostrarMensajeDelay(pokemon.getNombre() + " recuperó " + curacionReal + " PS");
                objetoUsado = true;

                //Actualizar UI si es el pokemon activo
                if (pokemon == pokemonJugador) {
                    actualizarVidaUI(barraVidaJugador, vidaJugador, pokemonJugador.getVidaActual(), pokemonJugador.getVida());
                    mostrarMensajeDelay("¿Qué debería hacer " + pokemonJugador.getNombre() + "?");
                }
                break;

            case Revivir:
                if (pokemon.getVidaActual() <= 0) {
                    //Revivir con la mitad de la vida
                    int vidaRevivir = pokemon.getVida() / 2;
                    pokemon.sanar(vidaRevivir);
                    mostrarMensajeDelay("¡" + pokemon.getNombre() + " ha sido revivido con " + vidaRevivir + " PS!");
                    objetoUsado = true;
                }
                break;
        }
        if (objetoUsado) {
            objeto.reducirCantidad();
        }
    }

    @FXML
    private void pokemon() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Pokemon.fxml"));
            Parent root = loader.load();

            //Obtener el controlador y pasar datos de pokemons
            ControladorPokemon controlador = loader.getController();
            controlador.initialize(jugador.getEquipoPokemon());

            //Obtener escena actual
            Scene escenaActual = areaBatalla.getScene();
            Stage stage = (Stage) escenaActual.getWindow();

            //Guardar controlador y escena actual para volver
            controlador.setEscenaAnterior(escenaActual);
            controlador.setControladorBatalla(this);

            //Cambiar escena
            Scene seleccionPokemon = new Scene(root, escenaActual.getWidth(), escenaActual.getHeight());
            stage.setScene(seleccionPokemon);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void pokemonSeleccionado(Pokemon pokemon) {
        if (pokemon != null && pokemon != pokemonJugador) {
            cambiarPokemon(pokemon);
        }
    }

    private void cambiarPokemon(Pokemon nuevoPokemon) {
        jugador.getEquipoPokemon().set(jugador.getEquipoPokemon().indexOf(pokemonJugador), pokemonJugador);

        this.pokemonJugador = nuevoPokemon;

        //Actualizar UI
        nombreJugador.setText(nuevoPokemon.getNombre());
        nivelJugador.setText("Nv " + nuevoPokemon.getNivel() + "   Exp " + nuevoPokemon.getExp());
        actualizarVidaUI(barraVidaJugador, vidaJugador, nuevoPokemon.getVidaActual(), nuevoPokemon.getVida());
        imagenJugador.setImage(new Image(Objects.requireNonNull(getClass().getResource(nuevoPokemon.getImagen())).toExternalForm()));

        mostrarMensajeDelay("¡Adelante " + nuevoPokemon.getNombre() + "!");
        PauseTransition pausa = new PauseTransition(Duration.millis(1000));
        pausa.setOnFinished(event -> {
            ataqueEnemigo();
        });
        pausa.play();
    }

    @FXML
    private void huir() {
        //Calcular probabilidad
        double diferenciaNiveles = pokemonJugador.getNivel() - pokemonEnemigo.getNivel();
        double porcentajeDiferencia = diferenciaNiveles * 0.05;
        double probabilidadBase = 0.5; //50%
        double probabilidad = probabilidadBase + porcentajeDiferencia;

        //Mínima de 10% y máxima de 90%
        probabilidad = Math.max(0.1, Math.min(0.9, probabilidad));

        boolean huyo = Math.random() < probabilidad;

        if (huyo) {
            mostrarMensajeDelay("¡Lograste huir con éxito!");

            //Degradado
            FadeTransition fade = new FadeTransition(Duration.millis(1011), imagenJugador);
            fade.setFromValue(1.0);
            fade.setToValue(0);

            //Transición a la izquierda
            TranslateTransition moverIzq = new TranslateTransition(Duration.millis(1011), imagenJugador);
            moverIzq.setByX(-200);

            //Animaciones al mismo tiempo
            ParallelTransition animacionHuida = new ParallelTransition(fade, moverIzq);

            animacionHuida.setOnFinished(event -> {

                setBotonesActivos(false);
            });

            animacionHuida.play();
        } else {
            mostrarMensajeDelay("¡No lograste escapar!");
            ataqueEnemigo();
        }
    }
}